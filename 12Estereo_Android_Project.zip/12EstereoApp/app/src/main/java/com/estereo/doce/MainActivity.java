package com.estereo.doce;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.*;
import android.graphics.Color;

public class MainActivity extends Activity {
  LinearLayout root; TextView status;
  @Override public void onCreate(Bundle b){ super.onCreate(b); build(); if(android.os.Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},7); }
  TextView tv(String s,int size){ TextView t=new TextView(this); t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(size); t.setGravity(Gravity.CENTER); return t; }
  void build(){
    root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setGravity(Gravity.CENTER); root.setPadding(28,30,28,30); root.setBackgroundColor(Color.rgb(8,8,8));
    ImageView logo=new ImageView(this); logo.setImageResource(com.estereo.doce.R.drawable.logo); root.addView(logo,new LinearLayout.LayoutParams(-1,190));
    TextView title=tv("12 ESTÉREO",30); title.setTextColor(Color.rgb(212,175,55)); title.setTypeface(null,1); root.addView(title,new LinearLayout.LayoutParams(-1,60));
    TextView fm=tv("101.3 FM",20); fm.setTextColor(Color.LTGRAY); root.addView(fm,new LinearLayout.LayoutParams(-1,45));
    TextView sub=tv("Transmitiendo desde El Doce, Antioquia\npara Colombia y el mundo",15); sub.setTextColor(Color.GRAY); root.addView(sub,new LinearLayout.LayoutParams(-1,65));
    status=tv("● FUERA DEL AIRE / PULSA ESCUCHAR",14); status.setTextColor(Color.LTGRAY); root.addView(status,new LinearLayout.LayoutParams(-1,50));
    Button play=new Button(this); play.setText("▶  ESCUCHAR EN VIVO"); play.setTextSize(18); play.setTextColor(Color.BLACK); play.setBackgroundResource(R.drawable.button_bg); root.addView(play,new LinearLayout.LayoutParams(-1,65));
    Button stop=new Button(this); stop.setText("■  DETENER"); stop.setTextSize(16); root.addView(stop,new LinearLayout.LayoutParams(-1,60));
    TextView wa=tv("WhatsApp 301 913 3840\nDJ Caled Rodriguez",14); wa.setTextColor(Color.GRAY); root.addView(wa,new LinearLayout.LayoutParams(-1,70));
    play.setOnClickListener(v->{ Intent i=new Intent(this,RadioService.class); i.setAction("PLAY"); if(android.os.Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i); status.setText("● CONECTANDO CON 12 ESTÉREO..."); });
    stop.setOnClickListener(v->{ Intent i=new Intent(this,RadioService.class); i.setAction("STOP"); startService(i); status.setText("● DETENIDA / PULSA ESCUCHAR"); });
    setContentView(root);
  }
}
