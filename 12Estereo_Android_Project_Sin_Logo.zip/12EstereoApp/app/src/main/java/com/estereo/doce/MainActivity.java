package com.estereo.doce;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Space;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.Typeface;

public class MainActivity extends Activity {
    private TextView status;

    private TextView tv(String text, float size) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(Color.WHITE);
        t.setTextSize(size);
        t.setGravity(Gravity.CENTER);
        return t;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        build();
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7);
        }
    }

    private void build() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(24, 30, 24, 30);
        root.setBackgroundColor(Color.rgb(5, 5, 5));

        TextView title = tv("12 ESTÉREO", 30);
        title.setTextColor(Color.rgb(212, 175, 55));
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        root.addView(title, new LinearLayout.LayoutParams(-1, 70));

        TextView fm = tv("101.3 FM", 21);
        fm.setTextColor(Color.LTGRAY);
        root.addView(fm, new LinearLayout.LayoutParams(-1, 45));

        TextView sub = tv("Transmitiendo desde El Doce, Antioquia\npara Colombia y el mundo", 15);
        sub.setTextColor(Color.GRAY);
        root.addView(sub, new LinearLayout.LayoutParams(-1, 70));

        status = tv("● FUERA DEL AIRE / PULSA ESCUCHAR", 14);
        status.setTextColor(Color.LTGRAY);
        root.addView(status, new LinearLayout.LayoutParams(-1, 55));

        Button play = new Button(this);
        play.setText("▶  ESCUCHAR EN VIVO");
        play.setTextSize(18);
        play.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        play.setTextColor(Color.BLACK);
        play.setAllCaps(false);
        play.setGravity(Gravity.CENTER);
        play.setBackgroundResource(R.drawable.button_play);
        root.addView(play, new LinearLayout.LayoutParams(-1, 68));

        Space gap = new Space(this);
        root.addView(gap, new LinearLayout.LayoutParams(1, 12));

        Button stop = new Button(this);
        stop.setText("■  DETENER");
        stop.setTextSize(17);
        stop.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        stop.setTextColor(Color.WHITE);
        stop.setAllCaps(false);
        stop.setGravity(Gravity.CENTER);
        stop.setBackgroundResource(R.drawable.button_stop);
        root.addView(stop, new LinearLayout.LayoutParams(-1, 62));

        TextView wa = tv("WhatsApp 301 913 3840\nDJ Caled Rodriguez", 14);
        wa.setTextColor(Color.GRAY);
        root.addView(wa, new LinearLayout.LayoutParams(-1, 70));

        play.setOnClickListener(v -> {
            Intent i = new Intent(this, RadioService.class);
            i.setAction("PLAY");
            if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(i);
            else startService(i);
            status.setText("● CONECTANDO CON 12 ESTÉREO...");
        });

        stop.setOnClickListener(v -> {
            Intent i = new Intent(this, RadioService.class);
            i.setAction("STOP");
            startService(i);
            status.setText("● DETENIDA / PULSA ESCUCHAR");
        });

        setContentView(root);
    }
}
