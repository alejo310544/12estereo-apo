# 12 Estéreo 101.3 FM – Android

Aplicación base para escuchar la señal de Internet de 12 Estéreo.

Stream configurado:
https://uk19freenew.listen2myradio.com/live.mp3?typeportmount=s1_27343_stream_371987632

Funciones: reproducción, detención y servicio de reproducción en segundo plano.

Para compilar: abrir este proyecto en Android Studio con Android SDK 35 y ejecutar `./gradlew assembleDebug`.
