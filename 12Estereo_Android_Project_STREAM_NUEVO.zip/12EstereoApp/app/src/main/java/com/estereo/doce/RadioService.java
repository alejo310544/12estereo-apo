package com.estereo.doce;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.IBinder;
import java.io.IOException;

public class RadioService extends Service {
    private static final String URL = "https://uk19freenew.listen2myradio.com/live.mp3?typeportmount=s1_27343_stream_371987632";
    private static final String CHANNEL_ID = "radio";
    private MediaPlayer player;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? "PLAY" : intent.getAction();
        if ("STOP".equals(action)) {
            stopRadio();
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }
        startPlayback();
        return START_STICKY;
    }

    private void startPlayback() {
        createChannel();

        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pending = PendingIntent.getActivity(
                this, 0, open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Notification notification = new Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("12 Estéreo 101.3 FM")
                .setContentText("Transmitiendo en vivo")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentIntent(pending)
                .setOngoing(true)
                .build();

        startForeground(12, notification);

        if (player != null && player.isPlaying()) return;

        try {
            if (player != null) player.release();
            player = new MediaPlayer();
            player.setAudioStreamType(android.media.AudioManager.STREAM_MUSIC);
            player.setDataSource(URL);
            player.setOnPreparedListener(MediaPlayer::start);
            player.setOnErrorListener((mp, what, extra) -> {
                stopRadio();
                return true;
            });
            player.prepareAsync();
        } catch (IOException e) {
            stopSelf();
        }
    }

    private void stopRadio() {
        if (player != null) {
            try { player.stop(); } catch (Exception ignored) {}
            player.release();
            player = null;
        }
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "12 Estéreo", NotificationManager.IMPORTANCE_LOW);
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    @Override
    public void onDestroy() {
        stopRadio();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
