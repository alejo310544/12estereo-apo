package com.estereo.doce;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private TextView status;
    private int gold = Color.rgb(212, 175, 55);
    private int goldLight = Color.rgb(247, 217, 106);
    private int bg = Color.rgb(7, 7, 7);
    private int panel = Color.rgb(20, 20, 20);

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView text(String value, float size, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        return t;
    }

    private GradientDrawable rounded(int fill, int strokeColor, int strokeDp, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) g.setStroke(dp(strokeDp), strokeColor);
        return g;
    }

    private void addSpace(LinearLayout root, int heightDp) {
        root.addView(new View(this), new LinearLayout.LayoutParams(1, dp(heightDp)));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        build();

        if (android.os.Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7);
        }
    }

    private void build() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(bg);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(22), dp(24), dp(22), dp(24));
        scroll.addView(root);

        TextView live = text("●  RADIO EN VIVO", 13, goldLight);
        live.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        live.setLetterSpacing(0.08f);
        root.addView(live, new LinearLayout.LayoutParams(-1, dp(36)));

        TextView title = text("12 ESTÉREO", 34, gold);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(54)));

        TextView frequency = text("101.3 FM", 22, Color.WHITE);
        frequency.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        root.addView(frequency, new LinearLayout.LayoutParams(-1, dp(38)));

        TextView location = text("TRANSMITIENDO DESDE EL DOCE, ANTIOQUIA\nPARA COLOMBIA Y EL MUNDO", 13, Color.rgb(160,160,160));
        location.setTypeface(Typeface.DEFAULT, Typeface.NORMAL);
        root.addView(location, new LinearLayout.LayoutParams(-1, dp(52)));

        addSpace(root, 12);

        LinearLayout statusBox = new LinearLayout(this);
        statusBox.setOrientation(LinearLayout.VERTICAL);
        statusBox.setGravity(Gravity.CENTER);
        statusBox.setPadding(dp(12), dp(10), dp(12), dp(10));
        statusBox.setBackground(rounded(panel, Color.rgb(65,65,65), 1, 22));

        TextView statusLabel = text("ESTADO DE LA EMISORA", 11, Color.GRAY);
        statusLabel.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        statusBox.addView(statusLabel, new LinearLayout.LayoutParams(-1, dp(22)));

        status = text("DETENIDA · PULSA ESCUCHAR", 15, Color.WHITE);
        status.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        statusBox.addView(status, new LinearLayout.LayoutParams(-1, dp(34)));
        root.addView(statusBox, new LinearLayout.LayoutParams(-1, dp(72)));

        addSpace(root, 22);

        TextView play = text("▶\nESCUCHAR LA EMISORA", 22, Color.BLACK);
        play.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        play.setLetterSpacing(0.02f);
        play.setBackground(rounded(gold, goldLight, 2, 38));
        play.setElevation(dp(5));
        play.setPadding(dp(10), dp(8), dp(10), dp(8));
        play.setClickable(true);
        root.addView(play, new LinearLayout.LayoutParams(-1, dp(118)));

        addSpace(root, 14);

        TextView stop = text("■  DETENER\nLA TRANSMISIÓN", 19, Color.WHITE);
        stop.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        stop.setBackground(rounded(Color.rgb(24,24,24), gold, 2, 34));
        stop.setPadding(dp(10), dp(8), dp(10), dp(8));
        stop.setClickable(true);
        root.addView(stop, new LinearLayout.LayoutParams(-1, dp(88)));

        addSpace(root, 20);

        TextView hint = text("Escucha 12 Estéreo con la pantalla apagada", 13, Color.rgb(130,130,130));
        root.addView(hint, new LinearLayout.LayoutParams(-1, dp(34)));

        LinearLayout whatsapp = new LinearLayout(this);
        whatsapp.setOrientation(LinearLayout.HORIZONTAL);
        whatsapp.setGravity(Gravity.CENTER_VERTICAL);
        whatsapp.setPadding(dp(16), dp(10), dp(16), dp(10));
        whatsapp.setBackground(rounded(Color.rgb(10,24,16), Color.rgb(37,211,102), 2, 24));
        whatsapp.setClickable(true);
        whatsapp.setElevation(dp(3));

        TextView waIcon = new TextView(this);
        waIcon.setBackgroundResource(R.drawable.whatsapp_icon);
        LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(dp(58), dp(58));
        iconParams.setMargins(0, 0, dp(14), 0);
        whatsapp.addView(waIcon, iconParams);

        LinearLayout waTexts = new LinearLayout(this);
        waTexts.setOrientation(LinearLayout.VERTICAL);
        waTexts.setGravity(Gravity.CENTER_VERTICAL);

        TextView waTitle = text("¿QUIERES PEDIR TU CANCIÓN?", 14, Color.WHITE);
        waTitle.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
        waTitle.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        waTexts.addView(waTitle, new LinearLayout.LayoutParams(-1, dp(25)));

        TextView waAction = text("Presiona aquí para pedirla por WhatsApp", 12, Color.rgb(37,211,102));
        waAction.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
        waAction.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        waTexts.addView(waAction, new LinearLayout.LayoutParams(-1, dp(23)));

        TextView waNumber = text("301 913 3840 · DJ Caled Rodriguez", 11, Color.rgb(175,175,175));
        waNumber.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
        waTexts.addView(waNumber, new LinearLayout.LayoutParams(-1, dp(21)));

        whatsapp.addView(waTexts, new LinearLayout.LayoutParams(0, -1, 1f));
        root.addView(whatsapp, new LinearLayout.LayoutParams(-1, dp(88)));

        addSpace(root, 6);

        TextView version = text("12 ESTÉREO · 101.3 FM", 11, Color.rgb(90,90,90));
        root.addView(version, new LinearLayout.LayoutParams(-1, dp(26)));

        play.setOnClickListener(v -> {
            Intent i = new Intent(this, RadioService.class);
            i.setAction("PLAY");
            if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(i);
            else startService(i);
            status.setText("CONECTANDO... 12 ESTÉREO");
        });

        stop.setOnClickListener(v -> {
            Intent i = new Intent(this, RadioService.class);
            i.setAction("STOP");
            startService(i);
            status.setText("DETENIDA · PULSA ESCUCHAR");
        });

        whatsapp.setOnClickListener(v -> {
            try {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/573019133840"));
                startActivity(i);
            } catch (Exception ignored) {}
        });

        setContentView(scroll);
    }
}
