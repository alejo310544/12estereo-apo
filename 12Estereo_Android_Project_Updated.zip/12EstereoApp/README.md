# 12 Estéreo 101.3 FM – Android

Aplicación base para escuchar la señal de Internet de 12 Estéreo.

Stream configurado:
https://fdsfdsfdsf.radio12345.com/intro.mp3

Funciones: reproducción, detención y servicio de reproducción en segundo plano.

Para compilar: abrir este proyecto en Android Studio con Android SDK 35 y ejecutar `./gradlew assembleDebug`.
