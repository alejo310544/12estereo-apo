package com.estereo.doce;

import android.app.*; import android.content.*; import android.media.MediaPlayer; import android.os.*; import java.io.IOException;

public class RadioService extends Service {
  private MediaPlayer player; private static final String URL="https://fdsfdsfdsf.radio12345.com/intro.mp3"; private static final int N=12;
  public int onStartCommand(Intent i,int flags,int id){ String a=i==null?"PLAY":i.getAction(); if("STOP".equals(a)){stopRadio(); stopForeground(true); stopSelf(); return START_NOT_STICKY;} startPlayback(); return START_STICKY; }
  void startPlayback(){ createChannel(); Intent pi=new Intent(this,MainActivity.class); PendingIntent p=PendingIntent.getActivity(this,0,pi,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT); Notification n=new Notification.Builder(this,"radio").setContentTitle("12 Estéreo 101.3 FM").setContentText("Transmitiendo en vivo").setSmallIcon(R.drawable.logo).setContentIntent(p).setOngoing(true).build(); startForeground(N,n); if(player!=null && player.isPlaying()) return; try{ if(player!=null) player.release(); player=new MediaPlayer(); player.setAudioStreamType(android.media.AudioManager.STREAM_MUSIC); player.setDataSource(URL); player.setOnPreparedListener(MediaPlayer::start); player.setOnErrorListener((mp,w,e)->{ stopRadio(); return true; }); player.prepareAsync(); }catch(IOException e){stopSelf();} }
  void stopRadio(){if(player!=null){try{player.stop();}catch(Exception e){} player.release(); player=null;}}
  void createChannel(){ if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel("radio","12 Estéreo",NotificationManager.IMPORTANCE_LOW); getSystemService(NotificationManager.class).createNotificationChannel(c);} }
  public void onDestroy(){stopRadio(); super.onDestroy();}
  public android.os.IBinder onBind(Intent i){return null;}
}
