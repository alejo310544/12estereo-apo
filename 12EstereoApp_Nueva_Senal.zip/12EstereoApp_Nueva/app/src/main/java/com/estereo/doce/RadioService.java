package com.estereo.doce;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.IBinder;

public class RadioService extends Service {

    private MediaPlayer player;
    private static final int NOTIFICATION_ID = 12;
    private static final String CHANNEL_ID = "12_estereo_radio";

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        stopExisting();

        createChannel();

        player = new MediaPlayer();
        player.setAudioAttributes(new AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build());

        try {
            player.setDataSource(MainActivity.STREAM);
            player.setOnPreparedListener(MediaPlayer::start);
            player.setOnErrorListener((mp, what, extra) -> {
                stopSelf();
                return true;
            });
            player.prepareAsync();

            startForeground(NOTIFICATION_ID, notification());

        } catch (Exception e) {
            stopSelf();
        }

        return START_STICKY;
    }

    private void stopExisting() {
        if (player != null) {
            try {
                player.stop();
            } catch (Exception ignored) {}
            player.release();
            player = null;
        }
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel =
                new NotificationChannel(
                    CHANNEL_ID,
                    "12 Estéreo",
                    NotificationManager.IMPORTANCE_LOW
                );
            getSystemService(NotificationManager.class)
                .createNotificationChannel(channel);
        }
    }

    private Notification notification() {
        Notification.Builder builder;

        if (Build.VERSION.SDK_INT >= 26)
            builder = new Notification.Builder(this, CHANNEL_ID);
        else
            builder = new Notification.Builder(this);

        return builder
            .setContentTitle("12 Estéreo 101.3 FM")
            .setContentText("Transmitiendo en vivo")
            .setSmallIcon(R.drawable.logo_12estereo)
            .setOngoing(true)
            .build();
    }

    @Override
    public void onDestroy() {
        stopExisting();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
