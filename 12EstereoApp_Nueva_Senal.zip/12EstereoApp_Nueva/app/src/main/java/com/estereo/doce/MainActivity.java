package com.estereo.doce;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {

    public static final String STREAM =
        "https://uk19freenew.listen2myradio.com/live.mp3?typeportmount=s1_27343_stream_371987632";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER_HORIZONTAL);
        layout.setPadding(28, 30, 28, 30);
        layout.setBackgroundColor(Color.rgb(9, 9, 9));

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.logo_12estereo);
        logo.setAdjustViewBounds(true);
        layout.addView(logo, new LinearLayout.LayoutParams(-1, 240));

        TextView title = new TextView(this);
        title.setText("12 ESTÉREO\n101.3 FM");
        title.setTextColor(Color.WHITE);
        title.setTextSize(27);
        title.setGravity(Gravity.CENTER);
        layout.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("\nTransmitiendo desde El Doce, Antioquia para el mundo");
        subtitle.setTextColor(Color.LTGRAY);
        subtitle.setTextSize(16);
        subtitle.setGravity(Gravity.CENTER);
        layout.addView(subtitle);

        Button play = button("📻  ESCUCHAR EN VIVO", 0xFFFFD000, Color.BLACK);
        Button stop = button("⏹  DETENER", 0xFFF1F1F1, Color.BLACK);
        Button whatsapp = button("💬  PEDIR MI CANCIÓN POR WHATSAPP", 0xFF19C463, Color.WHITE);

        layout.addView(play);
        layout.addView(stop);
        layout.addView(whatsapp);

        TextView dj = new TextView(this);
        dj.setText("\nDJ CALED RODRIGUEZ\nWhatsApp: 301 913 3840");
        dj.setTextColor(0xFFCCCCCC);
        dj.setTextSize(16);
        dj.setGravity(Gravity.CENTER);
        layout.addView(dj);

        play.setOnClickListener(v ->
            startService(new Intent(this, RadioService.class))
        );

        stop.setOnClickListener(v ->
            stopService(new Intent(this, RadioService.class))
        );

        whatsapp.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_VIEW,
                Uri.parse("https://wa.me/573019133840"));
            startActivity(i);
        });

        setContentView(layout);
    }

    private Button button(String text, int background, int foreground) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(foreground);
        b.setTextSize(15);
        b.setBackgroundColor(background);

        LinearLayout.LayoutParams p =
            new LinearLayout.LayoutParams(-1, 70);
        p.setMargins(0, 14, 0, 0);
        b.setLayoutParams(p);
        return b;
    }
}
